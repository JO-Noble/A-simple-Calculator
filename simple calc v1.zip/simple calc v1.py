from tkinter import *     

window = Tk()
window.title("calculator")
window.minsize(400,200)
window.configure(background="black")

# calculator brain 
expression = ""

def press(num):

    global expression
    
    expression = expression + str(num)

    equation.set(expression)

def equalpress():

    try:

        global expression

        total = str(eval(expression))
        
        equation.set(total)

        expression = ""

    except:

        equation.set(" error ")
        expression = ""

def clear():
    global expression
    expression = ""
    equation.set("")


equation = StringVar()

expression_field = Entry(window, textvariable=equation)

expression_field.grid(columnspan=8, ipadx=70)

# Button layout

button1 = Button(window,text="-1-", fg="white", bg="grey",
                command=lambda: press(1), height=1, width=7)
button1.grid(row=6, column=0)


button2 = Button(window,text="-2-", fg="white", bg="grey",
            command=lambda: press(2), height=1, width=7)
button2.grid(row=6, column=2)


button3 = Button(window,text="-3-", fg="white", bg="grey",
                command=lambda: press(3), height=1, width=7)
button3.grid(row=6, column=4)


button4 = Button(window,text="-4-", fg="white", bg="grey",
                command=lambda: press(4), height=1, width=7)
button4.grid(row=4, column=0)


button5 = Button(window,text="-5-", fg="white", bg="grey",
                command=lambda: press(5), height=1, width=7)
button5.grid(row=4, column=2)


button6 = Button(window,text="-6-", fg="white", bg="grey",
                command=lambda: press(6), height=1, width=7)
button6.grid(row=4, column=4)


button7 = Button(window,text="-7-", fg="white", bg="grey",
                command=lambda: press(7), height=1, width=7)
button7.grid(row=2, column=0)


button8 = Button(window,text="-8-", fg="white", bg="grey",
                command=lambda: press(8), height=1, width=7)
button8.grid(row=2, column=2)


button9 = Button(window,text="-9-", fg="white", bg="grey",
                command=lambda: press(9), height=1, width=7)
button9.grid(row=2, column=4)


button0 = Button(window,text="-0-", fg="white", bg="grey",
                command=lambda: press(0), height=1, width=7)
button0.grid(row=8, column=0)


button11 = Button(window,text="-.-", fg="white", bg="grey",
                command=lambda: press("."), height=1, width=7)
button11.grid(row=8, column=2)


button12 = Button(window,text="(-)", fg="white", bg="grey",
                command=lambda: press("-"), height=1, width=7)
button12.grid(row=8, column=4)


button13 = Button(window,text="➕", fg="white", bg="grey",
                command=lambda: press("+"), height=1, width=7)
button13.grid(row=6, column=6)


button14 = Button(window,text="➖", fg="white", bg="grey",
                command=lambda: press("-"), height=1, width=7)
button14.grid(row=6, column=8)


button15 = Button(window,text="-X-", fg="white", bg="grey",
                command=lambda: press("*"), height=1, width=7)
button15.grid(row=4, column=6)


button16 = Button(window,text="➗", fg="white", bg="grey",
                command=lambda: press("/"), height=1, width=7)
button16.grid(row=4, column=8)


button17 = Button(window,text="-(-", fg="white", bg="grey",
                command=lambda: press("("), height=1, width=7)
button17.grid(row=2, column=6)


button18 = Button(window,text="-)-", fg="white", bg="grey",
                command=lambda: press(")"), height=1, width=7)
button18.grid(row=2, column=8)


button19 = Button(window,text="-=-", fg="white", bg="grey",
                command=equalpress, height=1, width=7)
button19.grid(row=8, column=6)


button20 = Button(window,text="DEL", fg="white", bg="grey",
                command=clear, height=1, width=7)
button20.grid(row=8, column=8)

window.mainloop()
